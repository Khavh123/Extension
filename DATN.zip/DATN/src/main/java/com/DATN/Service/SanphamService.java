package com.DATN.Service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.DATN.DAO.SanphamDAO;
import com.DATN.Entity.Sanpham;

@Service
public class SanphamService {

    @Autowired
    private SanphamDAO sanphamDAO;

    public List<Sanpham> getAllSanpham() {
        return sanphamDAO.findAll();
    }
}
