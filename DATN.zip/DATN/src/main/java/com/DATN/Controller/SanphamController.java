package com.DATN.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.DATN.Service.SanphamService;

@Controller
public class SanphamController {

    @Autowired
    private SanphamService sanphamService;

    @GetMapping("/sanpham")
    public String listSanpham(Model model) {
        model.addAttribute("sanphams", sanphamService.getAllSanpham());
        return "sanpham"; // Tên file HTML trong thư mục templates
    }
}
