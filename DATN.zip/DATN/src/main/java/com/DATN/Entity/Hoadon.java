package com.DATN.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="HoaDon")
public class Hoadon {
	@Id
	private String maHD;
	private String maND;
	private String diachi;
	private String trangthaithanhtoan;
	private String nguoilapHD;
	public String getMaHD() {
		return maHD;
	}
	public void setMaHD(String maHD) {
		this.maHD = maHD;
	}
	public String getMaND() {
		return maND;
	}
	public void setMaND(String maND) {
		this.maND = maND;
	}
	public String getDiachi() {
		return diachi;
	}
	public void setDiachi(String diachi) {
		this.diachi = diachi;
	}
	public String getTrangthaithanhtoan() {
		return trangthaithanhtoan;
	}
	public void setTrangthaithanhtoan(String trangthaithanhtoan) {
		this.trangthaithanhtoan = trangthaithanhtoan;
	}
	public String getNguoilapHD() {
		return nguoilapHD;
	}
	public void setNguoilapHD(String nguoilapHD) {
		this.nguoilapHD = nguoilapHD;
	}
	
}
