package com.DATN.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="DanhGia")

public class Danhgia {
	@Id
	private String maDG;
	
	private String maND;
	private String maHD;
	private String binhluan;
	private String xephang;
	private String ngaytao;
	public String getMaDG() {
		return maDG;
	}
	public void setMaDG(String maDG) {
		this.maDG = maDG;
	}
	public String getMaND() {
		return maND;
	}
	public void setMaND(String maND) {
		this.maND = maND;
	}
	public String getMaHD() {
		return maHD;
	}
	public void setMaHD(String maHD) {
		this.maHD = maHD;
	}
	public String getBinhluan() {
		return binhluan;
	}
	public void setBinhluan(String binhluan) {
		this.binhluan = binhluan;
	}
	public String getXephang() {
		return xephang;
	}
	public void setXephang(String xephang) {
		this.xephang = xephang;
	}
	public String getNgaytao() {
		return ngaytao;
	}
	public void setNgaytao(String ngaytao) {
		this.ngaytao = ngaytao;
	}
	
	
}
