package com.DATN.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="PhanLoai")
public class Phanloai {
	 
	@Id
	private String maPL;
	
	private String LoaiSP;

	public String getMaPL() {
		return maPL;
	}

	public void setMaPL(String maPL) {
		this.maPL = maPL;
	}

	public String getLoaiSP() {
		return LoaiSP;
	}

	public void setLoaiSP(String loaiSP) {
		LoaiSP = loaiSP;
	}
	
	
}
