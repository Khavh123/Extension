package com.DATN.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.DATN.Entity.Sanpham;


@Repository
public interface SanphamDAO extends JpaRepository<Sanpham, String> {

}

