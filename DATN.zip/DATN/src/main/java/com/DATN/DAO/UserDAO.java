package com.DATN.DAO;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.DATN.Entity.Nguoidung;

@Repository
public interface UserDAO extends JpaRepository<Nguoidung, String> {
	 
}

