package com.DATN.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.DATN.Entity.Danhgia;

@Repository
public interface DanhgiaDAO extends JpaRepository<Danhgia, String> {

}
