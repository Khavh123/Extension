package com.DATN.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.DATN.Entity.Giohang;

@Repository
public interface GiohangDAO extends JpaRepository<Giohang, String> {

}
