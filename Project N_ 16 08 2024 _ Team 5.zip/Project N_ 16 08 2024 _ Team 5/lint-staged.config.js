export default {
  '*.{ts,tsx}': (filenames) => ['yarn pre-commit:validate'],
}
