import { safe as _safe } from '@wagmi/connectors';

export const safe = /*@__PURE__*/ _safe();
