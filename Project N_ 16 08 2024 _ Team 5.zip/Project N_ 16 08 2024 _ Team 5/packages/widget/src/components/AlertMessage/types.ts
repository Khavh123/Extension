export type Severity = 'info' | 'warning';
