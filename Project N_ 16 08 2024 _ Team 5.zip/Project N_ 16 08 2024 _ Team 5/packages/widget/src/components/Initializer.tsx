import { useInitializer } from '../hooks/useInitializer.js';

export const Initializer: React.FC = () => {
  useInitializer();
  return null;
};
