import bn from './bn.json' assert { type: 'json' };
import de from './de.json' assert { type: 'json' };
import en from './en.json' assert { type: 'json' };
import es from './es.json' assert { type: 'json' };
import fr from './fr.json' assert { type: 'json' };
import id from './id.json' assert { type: 'json' };
import it from './it.json' assert { type: 'json' };
import ja from './ja.json' assert { type: 'json' };
import ko from './ko.json' assert { type: 'json' };
import pt from './pt.json' assert { type: 'json' };
import th from './th.json' assert { type: 'json' };
import tr from './tr.json' assert { type: 'json' };
import uk from './uk.json' assert { type: 'json' };
import vi from './vi.json' assert { type: 'json' };
import zh from './zh.json' assert { type: 'json' };

export { bn, de, en, es, fr, id, it, ja, ko, pt, th, tr, uk, vi, zh };
