export const name = '@lifi/widget';
export const version = '3.0.2';
