export const defaultWalletConnectProjectId = '5432e3507d41270bee46b7b85bbc2ef8';
