export interface BookmarkError {
  type: 'name' | 'address';
  message: string;
}
