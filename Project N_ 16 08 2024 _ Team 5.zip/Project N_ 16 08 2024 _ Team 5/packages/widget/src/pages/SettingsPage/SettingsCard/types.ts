import type { ReactNode } from 'react';

export interface SettingCardTitle {
  icon: ReactNode;
  title: ReactNode;
}
