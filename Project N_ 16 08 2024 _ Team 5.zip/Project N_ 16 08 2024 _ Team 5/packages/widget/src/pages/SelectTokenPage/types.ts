export enum TokenFilterType {
  My,
  All,
}
