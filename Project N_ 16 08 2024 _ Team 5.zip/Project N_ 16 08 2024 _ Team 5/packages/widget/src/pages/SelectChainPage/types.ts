import type { FormTypeProps } from '../../stores/form/types.js';

export interface SelectChainPageProps extends FormTypeProps {
  selectNativeToken?: boolean;
}
