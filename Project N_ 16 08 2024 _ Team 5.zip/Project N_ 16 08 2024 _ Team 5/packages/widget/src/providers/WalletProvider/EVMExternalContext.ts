import { createContext } from 'react';

export const EVMExternalContext = createContext<boolean>(false);
