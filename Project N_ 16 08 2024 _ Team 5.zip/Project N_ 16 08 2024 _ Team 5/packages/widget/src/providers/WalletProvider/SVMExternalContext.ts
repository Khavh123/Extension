import { createContext } from 'react';

export const SVMExternalContext = createContext<boolean>(false);
