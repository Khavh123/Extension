/* eslint-disable */

<template>
  <ClientOnly>
    <WidgetContainer />
  </ClientOnly>
</template>
