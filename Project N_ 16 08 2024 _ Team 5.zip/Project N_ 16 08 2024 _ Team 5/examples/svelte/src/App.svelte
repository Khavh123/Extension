<script lang="ts">
  import LiFiWidget from './lib/LiFiWidget.svelte';
</script>

<LiFiWidget />

<style>
</style>
