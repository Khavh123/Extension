<script setup lang="ts">
// This starter template is using Vue 3 <script setup> SFCs
// Check out https://vuejs.org/api/sfc-script-setup.html#script-setup
import Widget from './components/Widget.vue';
</script>

<template>
  <Widget msg="LI.FI Widget + Vue + Vite" />
</template>
